package com.cg.mpa.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.Purchase;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.service.MobileService;
import com.cg.mpa.service.PurchaseService;
import com.cg.mpa.service.MobileServiceImpl;
import com.cg.mpa.service.PurchaseServiceImpl;

public class MobilePurchaseAppTest {
	static MobileService mobileservice=null;
	static PurchaseService purchaseService=null;
	static Scanner sc=null;
	public static void main(String args[])
	{
		sc=new Scanner(System.in);
		 purchaseService=new PurchaseServiceImpl();
		 mobileservice=new MobileServiceImpl();
		int choice=0;
		System.out.println("*****Welcome to Mobile Purchase Application*****");
		while(true)
		{
			System.out.println("What do you want to do>");
			System.out.println("\t 1.Add  \t 2.Show   \t 3.Delete Emp \t\n" +"\t 4.Search \t 5.Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1: insert();
			break;
			case 2: displayAllMobile();
		    break;
			case 3: delete();
		    break;
			case 4: search();
		    break;
		    default: System.exit(0);
		}
	}

}
	
	
	// INSERT
	
	private static void insert() 
	{
		try
		{
		System.out.println("enter mobile id");
		int mId=sc.nextInt();
		purchaseService.validatemobileid(mId);
		System.out.println("enter customer name");
		String cnm=sc.next();
		purchaseService.validateCustName(cnm);
		System.out.println("enter mail id");
		String mi=sc.next();
		purchaseService.MailId(mi);
		System.out.println("enter phone no");
		String pn=sc.next();
		purchaseService.validatePhoneno(pn);
		 
		Purchase obj=new Purchase(mId,cnm,mi,pn);
		
		int datainserted=purchaseService.addCust(obj,mId);
		if(datainserted==0)
			System.out.println("Sorry data not inserted");
	
	}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	
	// DISPLAY
	
	private static void displayAllMobile(){
		ArrayList<Mobile> mobList;
		try{
		
		
		mobList=mobileservice.display();
		System.out.println("\t mobID \t mobNAME \t mobprice \t mobquantity");
		for(Mobile m:mobList)
		{
			System.out.println("\t"+m.getMobileid()+"\t"+m.getName()+ "\t"+m.getPrice()+"\t" 
					+m.getQuantity());
		}
		}
		catch(MobileException e)
		{
			e.printStackTrace();
		}
	}
	
	// DELETE
	
	private static void delete(){
		try
		{
		System.out.println("enter mobile id to be deleted");
		int idel=sc.nextInt();
		
		int datadeleted=mobileservice.delete(idel);
		System.out.println("no of row deleted"+datadeleted);
		}
		
			
			catch(MobileException e)
		{
			e.printStackTrace();
		}
		}
	
	// SEARCH
	
	public static void search()
	{
	ArrayList<Mobile> mobList;
	
	try{
		
		System.out.println("Enter minimum value");
		double min=sc.nextDouble();
		System.out.println("Enter maximum value");
		double max=sc.nextDouble();
	mobList=mobileservice.search(min,max);
	System.out.println("\t mobID \t mobNAME \t mobprice \t mobquantity");
	for(Mobile m:mobList)
	{
		System.out.println("\t"+m.getMobileid()+"\t"+m.getName()+ "\t"+m.getPrice()+"\t" 
				+m.getQuantity());
	}
	}
	catch(MobileException e)
	{
		e.printStackTrace();
	}
}
	
	
	
}
