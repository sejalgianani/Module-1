package com.cg.mpa.dao;

import java.util.ArrayList;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.Purchase;
import com.cg.mpa.exception.MobileException;

public interface PurchaseDao  {

    
	public int addCust(Purchase p,int mid)throws MobileException;
	
	
	
}