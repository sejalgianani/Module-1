package com.cg.mpa.dao;

import java.util.ArrayList;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.exception.MobileException;

public interface MobileDao {

	public ArrayList<Mobile> display()throws MobileException;
	public int delete(int id)throws MobileException;
	public ArrayList<Mobile> search(double min,double max)throws MobileException;
	
}
