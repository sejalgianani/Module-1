package com.cg.mpa.dao;

import java.sql.*;
import java.util.ArrayList;

//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DButil;

public class MobileDaoImpl implements MobileDao {
	
	//Logger  daoLogger=null;
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	
	/*public EmpDaoImpl()
	{
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}*/
	
 ArrayList<Mobile> mobList=null;
	@Override
	public ArrayList<Mobile> display() throws MobileException  {
		// TODO Auto-generated method stub
		
		try
		{
			mobList=new ArrayList<Mobile>();
			con=DButil.getConn();
			String selectory="select * from mobile";
			st=con.createStatement();
			rs=st.executeQuery(selectory);
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getDouble("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
                
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}
	@Override
	public int delete(int id) throws MobileException {
		// TODO Auto-generated method stub
		try
		{
		con=DButil.getConn();
		String delqry="DELETE FROM mobile WHERE mobileid=?";
		  pst=con.prepareStatement(delqry);
		    pst.setInt(1,id);
		    data=pst.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
	return data;
	}
	
	
	@Override
	public ArrayList<Mobile> search(double min, double max) throws MobileException {
		// TODO Auto-generated method stub
		try
		{
			mobList=new ArrayList<Mobile>();
			con=DButil.getConn();
			String searchqry="select * from mobile where price>="+min+" and price<="+max;
			st=con.createStatement();
			//st.setDouble(1, min);
			//st.setDouble(2, max);
			rs=st.executeQuery(searchqry);
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getDouble("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobileException(e.getMessage());
		}
		/*finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
                
				throw new MobileException(e.getMessage());
			}
		}*/
		return mobList;
		
	}

}
