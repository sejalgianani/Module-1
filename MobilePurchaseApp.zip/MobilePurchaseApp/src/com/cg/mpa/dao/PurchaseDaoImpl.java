package com.cg.mpa.dao;
import java.sql.*;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.regex.Pattern;

import com.cg.mpa.exception.MobileException;
import com.cg.mpa.dto.Purchase;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DButil;

public class PurchaseDaoImpl implements PurchaseDao {
	
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	int count=0;
	
	
	public int addCust(Purchase p,int mid) throws MobileException {
		// TODO Auto-generated method stub
		
        try
        {
        	con=DButil.getConn();
        	String selectQry="select quantity from mobile where mobileid="+p.getMobileid();
    		st=con.createStatement();
    		//pst.setInt(1, mid);
    		rs=st.executeQuery(selectQry);
    		rs.next();
    	    count=Integer.parseInt(rs.getString("quantity"));
    		if(count>0)
    		{
    			System.out.println("quantity="+Integer.parseInt(rs.getString("quantity")));
    			String insertQry="Insert into purchasedetail values(id_seq.nextval,?,?,?,?,?)";
    			pst=con.prepareStatement(insertQry);
    			
    			pst.setString(1, p.getCname());
    			pst.setString(2, p.getMailid());
    			pst.setString(3, p.getPhoneno());
    			Timestamp date=new Timestamp(new java.util.Date().getTime());
    			pst.setTimestamp(4,date);
    			pst.setInt(5, p.getMobileid());
    			
    			data=pst.executeUpdate();
    			count--;
    			String updateQry="update mobile set quantity="+count+" where mobileid="+p.getMobileid();
    			st=con.createStatement();
    		    rs=st.executeQuery(updateQry);
    		}
    		 else
    		{
    			throw new MobileException("quantity=0");
    		}
		
	}
        catch(Exception e)
        {
        	e.printStackTrace();
        	throw new MobileException(e.getMessage());
        }
        return data;
        }
	
	
	
	
}
