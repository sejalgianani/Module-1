package com.cg.mpa.exception;

public class MobileException extends Exception{
	

		String msg;
		
		public MobileException(String msg)
		{
			super(msg);
		}

}
