package com.cg.mpa.dto;

public class Mobile {
	
	int mobileid;
	String name,quantity;
	double price;
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int mobileid, String name,  double price, String quantity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	
	

}
