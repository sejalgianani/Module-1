package com.cg.mpa.dto;

import java.sql.Date;

public class Purchase {
    
	int mobileid;
	static int id=0;
	int purchaseid;
	String cname,mailid,phoneno;
	Date purchasedate;
	
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public  int getPurchaseid() {
		return purchaseid;
	}
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	/*public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}*/
	
	public Purchase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Purchase(int mobileid, String cname, String mailid,
			String phoneno) {
		super();
		id++;
		this.mobileid = mobileid;
		this.purchaseid =id;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
	
	}
	
}	