package com.cg.mpa.service;

import java.util.ArrayList;

import com.cg.mpa.dao.MobileDaoImpl;
import com.cg.mpa.dao.MobileDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements MobileService{

	MobileDaoImpl mobDao=null;
	public MobileServiceImpl()
	{
		 mobDao=new MobileDaoImpl();
	}
	
	@Override
	public ArrayList<Mobile> display() throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.display();
	}

	@Override
	public int delete(int id) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.delete(id);
	}

	@Override
	public ArrayList<Mobile> search(double min, double max)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.search(min, max);
	}

}
