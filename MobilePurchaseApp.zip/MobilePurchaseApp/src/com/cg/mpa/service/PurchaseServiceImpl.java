package com.cg.mpa.service;

import java.util.regex.Pattern;

import com.cg.mpa.dao.PurchaseDao;
import com.cg.mpa.dao.PurchaseDaoImpl;
import com.cg.mpa.dto.Purchase;
import com.cg.mpa.exception.MobileException;

public class PurchaseServiceImpl implements PurchaseService {

	PurchaseDao obj=null;
	public PurchaseServiceImpl()
	{
		obj=new PurchaseDaoImpl();
	}
	
	@Override
	public int addCust(Purchase p,int mid) throws MobileException {
		// TODO Auto-generated method stub
		return obj.addCust(p,mid);
	}
	
	@Override
	public boolean validateCustName(String custName)throws MobileException
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern,custName))
		{
			return true;
		}
		else
		{
			throw new MobileException("invalid emp name.should start with capital and only 20 characters allowed");
		}

	}
	
	@Override
	public boolean MailId(String custmail)throws MobileException
	
	{
		String namePattern="[a-z0-9_.]+@[a-z]+.[a-z]+";
		if(Pattern.matches(namePattern,custmail))
		{
			return true;
		}
		else
		{
			throw new MobileException("invalid email id");
		}
	}
	
	@Override
	public boolean validatePhoneno(String phoneno) throws MobileException
	{
	
		if(phoneno.length()==10)
		{
			return true;
		}
		else
		{
			
			throw new MobileException("mobile no should be 10 digits!");
		}
		
		}
	
	@Override
	public boolean validatemobileid(int mobileid) throws MobileException
	{
	
		String namePattern="[0-9]{4}";
		if(Pattern.matches(namePattern,Integer.toString(mobileid)))
		{
			return true;
		}
		else
		{
			throw new MobileException("invalid mobile id");
		}
		
		}
	}

	


