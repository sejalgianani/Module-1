package com.cg.mpa.service;

import java.util.ArrayList;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.Purchase;
import com.cg.mpa.exception.MobileException;

public interface PurchaseService {

    
	public int addCust(Purchase p,int mid)throws MobileException;

	public boolean validateCustName(String cnm)throws MobileException;
	boolean validatePhoneno(String phoneno) throws MobileException;

	boolean MailId(String custmail) throws MobileException;

	boolean validatemobileid(int mobileid) throws MobileException;

	
	
}