package com.cg.ems.exception;

public class ErrorCode {

}
