package com.cg.ems.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient {
	
	static EmpService empService=null;
	static Scanner sc=null;
	public static void main(String args[])
	{
		sc=new Scanner(System.in);
		 empService=new EmpServiceImpl();
		int choice=0;
		System.out.println("*****Welcome to EMS*****");
		while(true)
		{
			System.out.println("What do you want to do>");
			System.out.println("\t 1.Add emp \t Show all emp \t 3.Update emp \t 4.Delete Emp \t\n" +"\t 5.Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1: insertEmp();
			break;
			case 2: displayAllEmp();
			break;
		    default: System.exit(0);
		}
	}

}
	
	private static void displayAllEmp(){
		try{
		
		ArrayList<Employee> empList=empService.getAllEmp();
		System.out.println("\t EMPID \t EMPNAME \t EMPSAL");
		for(Employee ee:empList)
		{
			System.out.println("\t"+ee.getEmpID()+"\t"+ee.getEmpName()+ "\t"+ee.getEmpSal());
		}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}
	
	
	private static void insertEmp(){
		try
		{
		System.out.println("enter emp id");
		int eId=sc.nextInt();
		System.out.println("enter name");
		String enm=sc.next();
		
		if(empService.validateEmpName(enm))
		{
			System.out.println("Enter salary");
			float esl = sc.nextFloat();
			Employee e1=new Employee(eId,enm,esl);
			int dataInserted= empService.addEmp(e1);
			if(dataInserted==1)
			{
				displayAllEmp();
			}
			else
			{
				System.out.println("sorry data is not inserted");
			}
			}
			}
		catch(EmployeeException e)
		{
			e.printStackTrace();
}
	}
}
	
