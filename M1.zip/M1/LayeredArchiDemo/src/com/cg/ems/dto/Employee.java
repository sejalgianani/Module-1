package com.cg.ems.dto;

public class Employee {

	private int empID;
	private String empName;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	private float empSal;
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	public Employee(int empID, String empName, float empSal) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.empSal = empSal;
	}
	
	public Employee(){
		super();
	}
	}

