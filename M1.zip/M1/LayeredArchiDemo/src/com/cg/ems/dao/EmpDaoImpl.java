package com.cg.ems.dao;

import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUTIL;

public class EmpDaoImpl implements EmpDao {
	
	Logger  daoLogger=null;
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	
	public EmpDaoImpl()
	{
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}
 ArrayList<Employee> empList=null;
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException  {
		// TODO Auto-generated method stub
		
		try
		{
			empList=new ArrayList<Employee>();
			con=DBUTIL.getConn();
			String selectory="select * from emp_157905";
			st=con.createStatement();
			rs=st.executeQuery(selectory);
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
                
				throw new EmployeeException(e.getMessage());
			}
		}
		return empList;
	}

	@Override
	public int addEmp(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
        try
        {
        
		con=DBUTIL.getConn();
		String insertQry="insert into emp_157905 values(?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, ee.getEmpID());
		pst.setString(2, ee.getEmpName());
		pst.setFloat(3, ee.getEmpSal());
		data=pst.executeUpdate();
	}
        catch(Exception e)
        {
        	e.printStackTrace();
        	throw new EmployeeException(e.getMessage());
        }
        return data;

	
}
}
