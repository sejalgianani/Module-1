import org.junit.Test;

//9.2.2
public class Test922 {

	@Test(expected=ExceptionCheck.class)
	public void checking()throws ExceptionCheck
	{
		Employee emp=new Employee(12345,"Programmer","A",2000);
		emp.check();
	}
}
