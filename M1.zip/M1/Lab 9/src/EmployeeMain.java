

import java.util.Scanner;


public class EmployeeMain {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String des="",ins="";
		int id;
		System.out.println("Enter emp ID");
		id=sc.nextInt();
		System.out.println("Enter emp salary");
		float salary=sc.nextFloat();
		
		try
		{
			if(salary<3000)
				throw new EmployeeException();
		if(salary>5000 && salary<20000)
		{	
		 des="System Associate";
		 ins="scheme c";
	}
		else if(salary>=20000 && salary<4000)
		{
			 des="Programmer";
			 ins="scheme B";
		
		}
		else if(salary>=40000)
		{
			 des="Manager";
			 ins="scheme A";
			
		}
		else if(salary<5000)
		{
			 des="clerk";
			 ins="no scheme";
			
		}
		Employee obj=new Employee(id,des,ins,salary);
		obj.display();
		

}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
}
}

