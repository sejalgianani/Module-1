import java.util.Scanner;

public class Person2 {
	
		String firstname;
		String lastname;
		char gender;
		int age;
		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public char getGender() {
			return gender;
		}

		public void setGender(char gender) {
			this.gender = gender;
		}

	
		/*public void Person2()
		{
		firstname=null;
		lastname=null;
		gender=' ';
		age=0;
		
		}*/
		
		public Person2(String f, String l, char g,int a)
		{
			firstname=f;
			lastname=l;
			gender=g;
			age=a;
			
		
		}

	public String display()
	{
		
		System.out.println("Firstname="+firstname);
		System.out.println("Lastname="+lastname);
		System.out.println("Gender="+gender);
		System.out.println("Age="+age);
		return firstname;
	}
	
	
	

}
