import static org.junit.Assert.*;

import org.junit.Test;


public class Person2Test {
	
	@Test
	public void testGetAge()
	{
		Person2 instance=new Person2("sejal","gianani",'f',22);
		int expResult=22;
		instance.setAge(22);
		int result=instance.getAge();
		assertEquals(expResult,result);
	}
	
	@Test
	public void testGetFirstName()
	{
		Person2 instance=new Person2("sejal","gianani",'f',22);
		String expResult="sejal";
		instance.setFirstname("sejal");
		String result=instance.getFirstname();
		assertEquals(expResult,result);
	}
	@Test
	public void testLastName()
	{
		Person2 instance=new Person2("sejal","gianani",'f',22);
		String expResult="gianani";
		instance.setLastname("gianani");
		String result=instance.getLastname();
		assertEquals(expResult,result);
	}
	
	@Test
	public void testGender()
	{
		Person2 instance=new Person2("sejal","gianani",'f',22);
		char expResult='f';
		instance.setGender('f');
		char result=instance.getGender();
		assertEquals(expResult,result);
	}
	
	@Test
	public void testDisplay()
	{
		Person2 instance=new Person2("sejal","gianani",'f',22);
		String a=instance.display();
		assertNotNull(a);
	}
	
	

}
