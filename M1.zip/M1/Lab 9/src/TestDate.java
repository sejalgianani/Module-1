import org.junit.*;
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.*;

	public class  TestDate
	{
		@Test
		public void testSetIntDay()
		{
			int day=06;
			Date instance=new Date(06,12,1995);
			instance.setDay(day);
			assertEquals(instance.getDay(),day);
		}
		
		@Test
		public void testSetMonth()
		{
			int month=11;
			Date instance=new Date(06,11,1995);
			instance.setMonth(month);
			assertEquals(instance.getMonth(),month);
		}
		
		@Test
		public void testGetIntDay()
		{
		
			Date instance=new Date(06,12,1995);
			int expResult=06;
			instance.setDay(06);
			int result=instance.getDay();
			assertEquals(expResult,result);
		}
		@Test
		public void testGetIntMonth()
		{
		    System.out.println("Get day");
			Date instance=new Date(06,12,1995);
			int expResult=12;
			instance.setMonth(12);
			int result=instance.getMonth();
			assertEquals(expResult,result);
		}
		
		@Test
		public void testGetIntYear()
		{
		    System.out.println("Get Year");
			Date instance=new Date(06,12,1995);
			int expResult=1995;
			instance.setYear(1995);
			int result=instance.getYear();
			assertEquals(expResult,result);
		}
		
	}
		
		


