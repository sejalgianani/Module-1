package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpUpdateDemo {
	public static void main(String args[])
	{
	Connection con=null;
	PreparedStatement pst=null;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter emp id whose salary is to be updated:");
	int uid=sc.nextInt();
	System.out.println("Enter emp  salary ");
	int sal=sc.nextInt();
	
	String upQry="UPDATE EMP_157905 SET emp_sal=?  where emp_id=?" ;
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
	    pst=con.prepareStatement(upQry);
	    pst.setInt(1,sal);
	    pst.setInt(2,uid);
	    
       int noodRecAffected=pst.executeUpdate();
	    System.out.println(noodRecAffected+"updated");
	}
	catch(ClassNotFoundException | SQLException e){
		e.printStackTrace();
	}
	}

}
