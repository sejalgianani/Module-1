package com.cg.util;

import java.util.Scanner;
import java.util.regex.*;

public class TestValidation {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your name");
	String ename=sc.next();
	String namePattern1="[A-Z][a-z]+";
	String namePattern2="[0-9]+";
	System.out.println("You have entered:"+ename);
	if(Pattern.matches(namePattern1,ename))
	{
		System.out.println("Valid name");
		
	}
	else
	{
		System.out.println("Invalid name");
	}
	
}
}
