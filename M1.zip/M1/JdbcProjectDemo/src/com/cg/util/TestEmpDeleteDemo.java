package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpDeleteDemo {
	public static void main(String args[])
	{
	Connection con=null;
	PreparedStatement pst=null;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter emp id to be deleted:");
	int id=sc.nextInt();
	
	String delQry="DELETE FROM EMP_157905 WHERE EMP_ID=? ";
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
	    pst=con.prepareStatement(delQry);
	    pst.setInt(1,id);

	    int noodRecAffected=pst.executeUpdate();
	    System.out.println(noodRecAffected+"row deleted");
	}
	catch(ClassNotFoundException | SQLException e){
		e.printStackTrace();
	}
	}

}
