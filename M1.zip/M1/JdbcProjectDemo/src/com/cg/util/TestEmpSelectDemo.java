package com.cg.util;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class TestEmpSelectDemo {
public static void main(String args[])
{
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
	    st=con.createStatement();
	    rs=st.executeQuery("SELECt * FROM emp_157905");
	    while(rs.next())
	    System.out.println(" : " +rs.getInt("emp_id")+" : " +rs.getString("emp_name") + " " +rs.getInt("emp_sal"));
	}
	catch(ClassNotFoundException e){
		e.printStackTrace();
	}
	catch(SQLException e){
		e.printStackTrace();
	}
}
}

