package com.cg.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
public class TestEmpInsertDemo{
	public static void main(String args[])
	{
	Connection con=null;
	PreparedStatement pst=null;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter emp id:");
	int id=sc.nextInt();
	System.out.println("Enter emp name:");
	String name=sc.next();
	System.out.println("Enter emp salary:");
	float sal=sc.nextFloat();
	String insertQry="INSERT INTO EMP_157905 VALUES(?,?,?) ";
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
	    pst=con.prepareStatement(insertQry);
	    pst.setInt(1,id);
	    pst.setString(2,name);
	    pst.setFloat(3,sal);
	    int noodRecAffected=pst.executeUpdate();
	    System.out.println(noodRecAffected+"row entered");
	}
	catch(ClassNotFoundException | SQLException e){
		e.printStackTrace();
	}
	}

}
