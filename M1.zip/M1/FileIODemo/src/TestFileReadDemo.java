import java.io.*;
public class TestFileReadDemo {

	public static void main(String args[])
	{
		File myFile=new File("D://Sejal Gianani/FileIODemo/src/TestEmpReadDemo.java");
		FileInputStream fis=null;
		try
		{
		 fis= new FileInputStream(myFile);
		 int data=fis.read();
		 while(data!=-1)
		 {
			 System.out.println(data);
			 data=fis.read();
		 }
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
