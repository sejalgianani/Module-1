import java.util.Scanner;
import java.io.*;

public class TestEmpDeserDemo {
	public static void main(String args[])
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try
		{
			
		 fis=new FileInputStream("EmpObj.obj");
		 ois=new ObjectInputStream(fis);
		 Employee ee=(Employee)ois.readObject();
		 System.out.println("Emp info from file"+ee);
		}
		catch(ClassNotFoundException | IOException e )
		{
			System.out.println(e);
		}
	}
	
}
