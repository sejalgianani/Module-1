import java.io.*;
import java.util.*;
public class TEstPropsWriteDemo {
	public static void main(String[] args)
	{
		FileOutputStream fos=null;
		Properties myObInfo=null;
		try
		{
			fos=new FileOutputStream("abInfo.properties");
			myObInfo=new Properties();
			myObInfo.setProperty("dbUser","System");
			myObInfo.setProperty("dbpwd","Root");
			myObInfo.store(fos,"this is databse info");
		System.out.println("data written");
		
		}
		catch(IOException e )
		{
			System.out.println(e);
		}
	}

}
