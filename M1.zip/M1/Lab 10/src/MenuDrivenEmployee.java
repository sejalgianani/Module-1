
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
	public class MenuDrivenEmployee{
		public static void main(String args[])
		{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		Statement st=null;
		Scanner sc=new Scanner(System.in);
		while(true)
		{
		 System.out.println("Enter your choice 1. Insert \n 2.Display \n 3.Delete");
		 int ch=sc.nextInt();
		
		 switch(ch)
		 {
		
		 // insert
		case 1:
		System.out.println("Enter emp id:");
		int id=sc.nextInt();
		System.out.println("Enter emp name:");
		String name=sc.next();
		System.out.println("Enter emp salary:");
		float sal=sc.nextFloat();
		
		String insertQry="INSERT INTO EMP_157905 VALUES(?,?,?) ";
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
		    pst=con.prepareStatement(insertQry);
		    pst.setInt(1,id);
		    pst.setString(2,name);
		    pst.setFloat(3,sal);
		    int noodRecAffected=pst.executeUpdate();
		    System.out.println(noodRecAffected+"row entered");
		}
		catch(ClassNotFoundException | SQLException e){
			e.printStackTrace();
		}
		break;
		//display
		case 2:
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
			    st=con.createStatement();
			    rs=st.executeQuery("SELECt * FROM emp_157905");
			    while(rs.next())
			    System.out.println(" : " +rs.getInt("emp_id")+" : " +rs.getString("emp_name") + " " +rs.getInt("emp_sal"));
			}
			catch(ClassNotFoundException e){
				e.printStackTrace();
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		break;
		
		//delete
		case 3:
			System.out.println("Enter emp id to be deleted:");
			int iid=sc.nextInt();
			
			String delQry="DELETE FROM EMP_157905 WHERE EMP_ID=? ";
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg16","lab1boracle");
			    pst=con.prepareStatement(delQry);
			    pst.setInt(1,iid);

			    int noodRecAffected=pst.executeUpdate();
			    System.out.println(noodRecAffected+"row deleted");
			}
			catch(ClassNotFoundException | SQLException e){
				e.printStackTrace();
			}
		
		}

	}

		}
}
