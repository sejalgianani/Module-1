import java.io.*;
import java.util.*;
public class PersonProp {
	
	public static void main(String args[])
	{
		FileInputStream fis=null;
		Properties myPros=null;
		
		try
		{
			
		fis=new FileInputStream("D://Sejal Gianani/Lab 10/src/Personprop.properties");
		myPros=new Properties();
		myPros.load(fis);
		System.out.println(myPros);
		
		String id=myPros.getProperty("id");
		String name=myPros.getProperty("name");
		
		String gender=myPros.getProperty("gender");
		
		System.out.println(name+":"+gender+":"+id);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
