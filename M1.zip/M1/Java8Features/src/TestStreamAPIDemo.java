import java.util.*;
import java.util.stream.Stream;
public class TestStreamAPIDemo {

	public static void main(String args[])
	{
		List<Integer> intList=Arrays.asList(45,8,10,3,89,456);
		Stream<Integer> intListStream=intList.stream();
		
		intListStream.filter((num)->num>10).forEach(num->System.out.println(num));		System.out.println("******print distinct********");
	}
}
