
public class MaxfinderImpl implements MaxFinder {
	
	@Override
	public int max(int a,int b)
	{
		return(a>b? a:b);
	}

}
 