
public class Employee implements Comparable<Employee> {
	
	String id;
	 
	 float salary;
	 String designation;
	 String insuranceScheme;
	 
 public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public float getSalary() {
		return salary;
	}
	public void setSalary(float sialary) {
		this.salary = sialary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	Employee(String i,String d,String is,float s)
	{
		id=i;
		designation=d;
		insuranceScheme=is;
		salary=s;
	
		
		
	}
	
	

 @Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", designation="
				+ designation + ", insuranceScheme=" + insuranceScheme + "]";
	}
@Override
 public int compareTo(Employee emp)
 {
	 if(this.salary<emp.salary)
	 return -1;
	 else if(this.salary>emp.salary)
		 return 1;
	 return 0;
}

}
