import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;

public class EmployeeInsurance {
HashMap<String,Employee> empList=new HashMap<String,Employee>();
public void add(String id, Employee emp)
{
	empList.put(id, emp);
}

public void delete(String id)
{
	empList.remove(id);
	
}
public void print(){
	Set<Map.Entry<String,Employee>> empSet=empList.entrySet();
	Iterator<Map.Entry<String,Employee>> it=empSet.iterator();
	while(it.hasNext())
	{
		Map.Entry<String,Employee> entry=it.next();
		System.out.println("Key:"+entry.getKey()+"name:"+entry.getValue());
	}
		
	}
public void sort()
{
	Collection<Employee> emp=empList.values();
	TreeSet<Employee> empset=new TreeSet<Employee>(emp);
	Iterator<Employee> it=empset.iterator();
	while(it.hasNext())
	{
		Employee emp2=it.next();
		System.out.println(emp2);
	}
	
}
public void search(String sch)
{
	Set<Map.Entry<String, Employee>> mapSet=empList.entrySet();
	Iterator<Map.Entry<String,Employee>> it=mapSet.iterator();
	while(it.hasNext())
	{
		Map.Entry<String,Employee> scheme=it.next();
		if(sch.equals(scheme.getValue().getInsuranceScheme()))
		{
			System.out.println(scheme.getKey()+"\t" +scheme.getValue());
		}
		}
	}
}



