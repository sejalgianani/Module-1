import java.util.Scanner;
public class EmployeeMain {
	public static void main(String args[])
	{
		EmployeeInsurance obj=new EmployeeInsurance(); 
		Scanner sc=new Scanner(System.in);
		String des="",id="",ins="";
		System.out.println("Enter no of employees");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
		System.out.println("Enter emp ID");
		id=sc.next();
		System.out.println("Enter emp salary");
		float salary=sc.nextFloat();
		System.out.println("Enter emp designation");
		des=sc.next();
		System.out.println("Enter emp ins scheme");
		ins=sc.next();
		Employee ob=new Employee(id,des,ins,salary);
		obj.add(id,ob);
		}
		System.out.println("Enter emp ID to be deleted");
		String di=sc.next();
		obj.delete(di);
		System.out.println("Enter emp insurance scheme");
		String scheme=sc.next();
		System.out.println(" emp details according to insurance scheme");
		obj.search(scheme);
		
		obj.sort();
		obj.print();
		

}
}

