import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class TestCalculator {
public static void main(String args[])
{
	Logger myLogger=Logger.getLogger(TestCalculator.class);
	PropertyConfigurator.configure("log4j.properties");
	Scanner sc=new Scanner(System.in);
	myLogger.info("This is a debug message");
	myLogger.info("this is a warn message");
	myLogger.info("This is a fatal message");
	System.out.println("enter a:");
	int a=sc.nextInt();
	myLogger.info("User entered a");
	System.out.println("enter b:");
	int b=sc.nextInt();
	myLogger.info("User entered b");
	int c=0;
    try
    {
    	c=a/b;
    	myLogger.info("c"+ " "+c);
    	System.out.println("Result:"+c);
    }
    catch(ArithmeticException e)
    {
    	
    	myLogger.error(e.getMessage());
    	e.printStackTrace();
    }
}

}
