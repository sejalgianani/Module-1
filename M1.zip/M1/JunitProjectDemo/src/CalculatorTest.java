import org.junit.*;
public class CalculatorTest {
	
	static Calculator calc=null;
	@BeforeClass
	public static void setup()
	{
		calc=new Calculator();
		System.out.println("Setup is call once "+"Before the execution of"+"all test cases");
		
	}
	@AfterClass
	public  static void teardown()
	{
		System.out.println("Teardown is call once "+"Before the execution of"+"all test cases");
		
	}
	@After
	public void destroy()
	{
		System.out.println("Destroy is call once "+"Before the execution of"+"all test cases");
		
	}
	
	@Test
	public void testDivide1()
	{
		Assert.assertEquals(1,calc.divide(100));
	}
	@Test
	public void testDivide2()
	{
		Assert.assertEquals(20,calc.divide(5));
	}
	
	@Test(expected=ArithmeticException.class)
	public void testDivide3()
	{
		Assert.assertEquals(1,calc.divide(0));
	}
}
