

import java.util.HashSet;
import java.util.Iterator;
public class TestHashDemo {
public static void main(String args[]){
	HashSet<Integer> intset=new HashSet<Integer>(4);
	Integer i1=new Integer(40);
	Integer i2=new Integer(40);
	Integer i3=new Integer(40);
	Integer i4=new Integer(40);
	String str=new String("hello");
	
	intset.add(i1);
	intset.add(i1);
	intset.add(i1);

	Iterator<Integer> it=intset.iterator();
	while(it.hasNext())
	{
		Integer ii=it.next();
		System.out.println("entry="+ii);
	}
}
}
