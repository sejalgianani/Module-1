import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Collection;


public class TestHashMapDemo {
	public static void main(String args[])
	{
		HashMap<Long,String> directory=new HashMap<Long,String>();
		directory.put(123457687L, "Sejal");
		directory.put(1234576866L, "Sruti");
		directory.put(1234324357687L, "Gurveen");
		directory.put(123451117L, "Bhavin");
		directory.put(123457687L, "Sejalgg");
		System.out.println(directory);
		Set<Map.Entry<Long, String>> mapSet=directory.entrySet();
		Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
		while(it.hasNext())
		{
			Map.Entry<Long,String> entry=it.next();
			System.out.println("Key"+entry.getKey()+ "Name:"+entry.getValue());
		}
		
		Set<Long> KSet=directory.keySet();
		Iterator<Long> itk=KSet.iterator();
		while(itk.hasNext())
		{
			Long key=itk.next();
			System.out.println("Key"+key);
		}
		
		Collection<String> VSet=directory.values();
		Iterator<String> itv=VSet.iterator();
		while(itv.hasNext())
		{
			String value=itv.next();
			System.out.println("value"+value);
		}		
	}

}
