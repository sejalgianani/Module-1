import java.util.*;
import java.util.Iterator;
public class TestTreeSetDemo {
public static void main(String args)
{
	TreeSet<Integer> intset=new TreeSet<Integer>();
	Integer i1=new Integer(40);
	Integer i2=new Integer(10);
	Integer i3=new Integer(40);
	Integer i4=new Integer(30);
	String str=new String("hello");
	
	intset.add(i1);
	intset.add(i1);
	intset.add(i1);

	Iterator<Integer> it=intset.iterator();
	while(it.hasNext())
	{
		Integer ii=it.next();
		System.out.println("entry="+ii);
	}
}
}
