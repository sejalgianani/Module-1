
import java.io.*;
public class Reverse {
	
		public static void main(String args[])
		{
			
			String rev="";
			File myFile=new File("D://Sejal Gianani/FileIODemo/src/TestEmpReadDemo.java");
			FileInputStream fis=null;
			FileOutputStream fos=null;
			
			try
			{
			 fis= new FileInputStream(myFile);
			 fos=new FileOutputStream("MyFile.txt");
			
			 int data=fis.read();
			 while(data!=-1)
			 {
				rev=(char)data+rev;
				data=fis.read();
			 }
			 byte[] s=rev.getBytes();
			 //System.out.println(rev);
			 fos.write(s);
			 fos.flush();
			 fos.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}


