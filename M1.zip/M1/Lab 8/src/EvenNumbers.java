import java.io.*;
import java.util.*;
public class EvenNumbers {
public static void main(String args[])
{
	try
	{
		FileWriter fw=new FileWriter("Numbers.txt");
		fw.write("0,1,2,3,4,5,6,7,8,9,10");
		fw.flush();
		Scanner sc=new Scanner(new File("Numbers.txt"));
		sc.useDelimiter(",");
		while(sc.hasNext())
		{
			int num=sc.nextInt();
			if(num%2==0)
			System.out.println(num);
			
		}
		}
	catch( IOException e )
	{
		System.out.println(e);
	}
}
}
