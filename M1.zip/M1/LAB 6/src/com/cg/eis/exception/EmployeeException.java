package com.cg.eis.exception;
public class EmployeeException extends Exception {
public String toString()
{
	return ("error");
}
}
