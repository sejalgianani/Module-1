
public class PersonMain {
	public static void main(String args[])
	{
	Person p=new Person(null,null, 'f');
}
}