
public class AcccountMain {
	public static void main(String args[])
	{
		Person obj1=new Person("smith","G",'m',24);
		Person obj2=new Person("kathy","G",'f',5);
	}

}
