
public class Account {
static int n=1;
private long accNum;
private double balance;
private Person accholder;
public long getAccNum()
{
return accNum;
}
Account(double b, Person p1)
{
	accNum=n;
	n++;
	balance=b;
	accholder=p1;
	
}
public void setAccNum(long AccNum)
{
	this.accNum=accNum;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Person getAccholder() {
	return accholder;
}
public void setAccholder(Person accholder) {
	this.accholder = accholder;
}

public void deposit(double amount)
{
	balance=balance+amount;
}

public void withdraw(double amount)
{
    if(balance>=500)
	balance=balance-amount;
    else
    	System.out.println("Minimum balance:Withdraw not posssible");
}
}