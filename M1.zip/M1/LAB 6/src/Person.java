import java.util.Scanner;

class MyException extends Exception
{
	@Override
	public String toString()
	{
		return("Error");
	}
}
class AgeValidation extends Exception
{
	@Override
	public String toString()
	{
		return("Age should be above 15");
	}
}
public class Person {
	
		String firstname;
		String lastname;
		char gender;
		float age;
		public float getAge() {
			return age;
		}

		public void setAge(float age) {
			this.age = age;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public char getGender() {
			return gender;
		}

		public void setGender(char gender) {
			this.gender = gender;
		}

	
		Person()
		{
		firstname=null;
		lastname=null;
		gender=' ';
		age=0;
		
		}
		
		Person(String f, String l, char g,float a)
		{
			firstname=f;
			lastname=l;
			gender=g;
			age=a;
			try{
				if(firstname==null && lastname==null)
				throw new MyException();
				if(age<=15)
					throw new AgeValidation();
				
				Scanner sc=new Scanner(System.in);
				double initialbal=sc.nextDouble();
				Account a1=new Account(initialbal,this);
				a1.deposit(2000);
				System.out.println("Balance in Smith acc"+a1.getBalance());
				//display();
				
			}
			catch(MyException e)
			{
				System.out.println(e);
			}
			catch(AgeValidation e)
			{
				System.out.println(e);
			}
		}

	public void display()
	{
		
		System.out.println("Firstname="+firstname);
		System.out.println("Lastname="+lastname);
		System.out.println("Gender="+gender);
		System.out.println("Age="+age);
		
	}
	
	
	

}
