import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class sort {
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of products");
		int n=sc.nextInt();
		ArrayList<String> product=new ArrayList<String>();
		for(int i=0;i<n;i++)
		{
			product.add(sc.next());
		}
		Collections.sort(product);
		System.out.println("Sorted list="+product);
		
	}

	}


