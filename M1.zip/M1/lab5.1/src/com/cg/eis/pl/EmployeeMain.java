package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class EmployeeMain {
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);

	String des="",id="";
	System.out.println("Enter Employee id");
	id=sc.nextLine();
	System.out.println("Enter Employee designation");
	des=sc.nextLine();
	System.out.println("Enter Employee salary");
	float salary=sc.nextFloat();
	Employee obj=new Employee(id,des,salary);
	EmployeeServiceImplementation ser = new EmployeeServiceImplementation(obj);

	
	
	}
}

