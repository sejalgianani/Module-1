package com.cg.eis.service;
import com.cg.eis.bean.*;



import java.util.Scanner;

 interface EmployeeService {
	String findinScheme(float salary);
	void display(Employee emp);
	
 }
public class EmployeeServiceImplementation implements EmployeeService{

	
	public EmployeeServiceImplementation(Employee obj)
	{
		display(obj);
	}
	
	public String findinScheme(float salary)
	{
		String ins="";
	
	if(salary>5000 && salary<20000)
	{	
	 
	 ins="scheme c";
   }
	else if(salary>=20000 && salary<40000)
	{
		
		 ins="scheme B";
	
	}
	else if(salary>=40000)
	{
		 
		 ins="scheme A";
		
	}
	else if(salary<5000)
	{
		
		 ins="no scheme";
		
	}
	return ins;
	}
	
	
	public void display(Employee emp)
	{
		System.out.println("designation="+findinScheme(emp.getSalary()));
		System.out.println("designation="+emp.getId());
	}
	
	
}
 
