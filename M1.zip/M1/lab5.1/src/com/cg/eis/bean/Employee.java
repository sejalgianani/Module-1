package com.cg.eis.bean;

public class Employee {
	
	String id;
	 public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	String name;
	 float salary;
	 String designation;
	 String insuranceScheme;
	 
 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float sialary) {
		this.salary = sialary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	public Employee(String i,String d,float s)
	{
		id=i;
		designation=d;
		salary=s;
	
		
		
	}
	
	

 
}
